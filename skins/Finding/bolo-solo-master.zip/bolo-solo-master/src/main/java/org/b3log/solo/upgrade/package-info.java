/**
 * Upgrade scripts.
 */
package org.b3log.solo.upgrade;
