/**
 * Console requests (Articles, Comments, Preference, etc, management) processing.
 */
package org.b3log.solo.processor.console;
